Sword modelled with Amapi
4584 polygons
Total of 5 objects
I provided texture for the handle only

---------------------------------

Ep�e mod�lis�e avec Amapi
4584 polygones 
5 objets s�par�s
La texture est fournie seulement pour la poign�e


=================================
From The Virtual lands Meshbank

http://o.ffrench.free.fr/meshbank
=================================